﻿namespace MyApiExample.Models.Enum;
    public enum EProviderType
    {
        BigDataCorp=1,
        Assertiva=2
    }
