﻿using System;
using System.Collections.Generic;

namespace MyApiExample.Models
{
    public class BigdataCorp
    {
        public List<Result> Result { get; set; }
    }

    public class Result
    {
        public string MatchKeys { get; set; }
        public BasicData BasicData { get; set; }
    }

    public class BasicData
    {
        public string TaxIdNumber { get; set; }
        public string TaxIdCountry { get; set; }
        public AlternativeIdNumbers AlternativeIdNumbers { get; set; }
        public string OfficialName { get; set; }
        public string TradeName { get; set; }
        public Aliases Aliases { get; set; }
        public int? NameUniquenessScore { get; set; }
        public int? OfficialNameUniquenessScore { get; set; }
        public int? TradeNameUniquenessScore { get; set; }
        public DateTime? FoundedDate { get; set; }
        public int? Age { get; set; }
        public bool? IsHeadquarter { get; set; }
        public string HeadquarterState { get; set; }
        public bool? IsConglomerate { get; set; }
        public string TaxIdStatus { get; set; }
        public string TaxIdOrigin { get; set; }
        public DateTime? TaxIdStatusDate { get; set; }
        public DateTime? TaxIdStatusRegistrationDate { get; set; }
        public string TaxRegime { get; set; }
        public string CompanyType_ReceitaFederal { get; set; }
        public TaxRegimes TaxRegimes { get; set; }
        public List<Activity> Activities { get; set; }
        public LegalNature LegalNature { get; set; }
        public string SpecialSituation { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public AdditionalOutputData AdditionalOutputData { get; set; }
        public HistoricalData HistoricalData { get; set; }
    }

    public class AlternativeIdNumbers
    {
        public string StateRegistrationSP { get; set; }
    }

    public class Aliases
    {
        public string UnstandardizedRFOfficialName { get; set; }
        public string UnstandardizedRFTradeName { get; set; }
    }

    public class TaxRegimes
    {
        public bool Simples { get; set; }
    }

    public class Activity
    {
        public bool IsMain { get; set; }
        public string Code { get; set; }
        public string activity { get; set; }
    }

    public class LegalNature
    {
        public string Code { get; set; }
        public string Activity { get; set; }
    }

    public class AdditionalOutputData
    {
        public string Capital { get; set; }
        public string CapitalRS { get; set; }
        public string NIRE { get; set; }
        public string COMEX { get; set; }
        public DateTime? COMEXLastUpdate { get; set; }
    }

    public class HistoricalData
    {
        public bool HasChangedTradeName { get; set; }
        public bool HasChangedTaxRegime { get; set; }
        public HistoricalDataEvolution HistoricalDataEvolution { get; set; }
    }

    public class HistoricalDataEvolution
    {
        public List<HistoricalDataItem> TradeName { get; set; }
        public List<HistoricalDataItem> TaxRegime { get; set; }
    }

    public class HistoricalDataItem
    {
        public string Value { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }

    public class Status
    {
        public List<StatusDetail> basic_data { get; set; }
    }

    public class StatusDetail
    {
        public int Code { get; set; }
        public string Message { get; set; }
    }
}
