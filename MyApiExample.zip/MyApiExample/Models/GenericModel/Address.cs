﻿
using MyApiExample.Models.GenericModel;

public class Address
{
    public string StreetType { get; set; }
    public string StreetName { get; set; }
    public int Number { get; set; }
    public string Complement { get; set; }
    public string Neighborhood { get; set; }
    public string City { get; set; }
    public string State { get; set; }
    public string PostalCode { get; set; }
    public double? Latitude { get; set; }
    public double? Longitude { get; set; }
}
