﻿
using MyApiExample.Models.GenericModel;

public class Phone
{
    public string Number { get; set; }
    public string Relation { get; set; }
    public bool DoNotDisturb { get; set; }
    public string LastContact { get; set; }
    public bool? IsHotline { get; set; }
    public bool? HasWhatsApp { get; set; }
}
