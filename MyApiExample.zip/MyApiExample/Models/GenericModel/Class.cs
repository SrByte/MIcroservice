﻿namespace MyApiExample.Models.GenericModel
{
    using System;
    using System.Collections.Generic;


    public class Address
    {
        public string StreetType { get; set; }
        public string StreetName { get; set; }
        public int Number { get; set; }
        public string Complement { get; set; }
        public string Neighborhood { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
    }

    public class Phone
    {
        public string Number { get; set; }
        public string Relation { get; set; }
        public bool DoNotDisturb { get; set; }
        public string LastContact { get; set; }
        public bool? IsHotline { get; set; }
        public bool? HasWhatsApp { get; set; }
    }

    public class BasicData
    {
        public string TaxIdNumber { get; set; }
        public string OfficialName { get; set; }
        public string? FoundedDate { get; set; }
        public bool IsHeadquarter { get; set; }
        public string State { get; set; }
        public string LegalNature { get; set; }
        public string TaxRegime { get; set; }
        public string TradeName { get; set; }
        public string Status { get; set; }
        public string Activity { get; set; }
        public int? Employees { get; set; }
    }

    public class GenericModel
    {
        public BasicData BasicData { get; set; }
        public List<CNAE> CNAEs { get; set; }
        public List<Address> Addresses { get; set; }
        public List<Phone> Phones { get; set; }
        public List<Partner> Partners { get; set; }
        public List<string> Emails { get; set; }

        public GenericModel()
        {
            CNAEs = new List<CNAE>();
            Addresses = new List<Address>();
            Phones = new List<Phone>();
            Partners = new List<Partner>();
            Emails = new List<string>();
        }
    }

}
