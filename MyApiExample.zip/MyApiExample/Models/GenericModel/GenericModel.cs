﻿
using MyApiExample.Models.GenericModel;

public class GenericModel
{
    public BasicData BasicData { get; set; }
    public List<CNAE> CNAEs { get; set; }
    public List<Address> Addresses { get; set; }
    public List<Phone> Phones { get; set; }
    public List<Partner> Partners { get; set; }
    public List<string> Emails { get; set; }

    public GenericModel()
    {
        CNAEs = new List<CNAE>();
        Addresses = new List<Address>();
        Phones = new List<Phone>();
        Partners = new List<Partner>();
        Emails = new List<string>();
        BasicData= new BasicData();
    }
}