﻿namespace MyApiExample.Models.GenericModel
{
    using System;
    using System.Collections.Generic;

    public class CNAE
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public string Group { get; set; }
    }
}