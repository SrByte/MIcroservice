﻿
using MyApiExample.Models.GenericModel;

public class BasicData
{
    public string TaxIdNumber { get; set; }
    public string OfficialName { get; set; }
    public string? FoundedDate { get; set; }
    public bool IsHeadquarter { get; set; }
    public string State { get; set; }
    public string LegalNature { get; set; }
    public string TaxRegime { get; set; }
    public string TradeName { get; set; }
    public string Status { get; set; }
    public string Activity { get; set; }
    public int? Employees { get; set; }
}