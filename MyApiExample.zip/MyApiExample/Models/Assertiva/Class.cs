﻿
namespace MyApiExample.Models.Assertiva;

using System;
using System.Collections.Generic;
public class Response
{
    public Resposta resposta { get; set; }
    public string? alerta { get; set; }
}

public class Resposta
{
    public DadosCadastrais dadosCadastrais { get; set; }
    public List<CnaeSecundario> cnaesSecundarias { get; set; }
    public Telefones telefones { get; set; }
    public List<Endereco> enderecos { get; set; }
    public List<Email> emails { get; set; }
    public List<Socio> socios { get; set; }
    public HistoricoConsultasPorSegmento historicoConsultasPorSegmento { get; set; }
}

public class DadosCadastrais
{
    public string? cnpj { get; set; }
    public string? razaoSocial { get; set; }
    public string? dataAbertura { get; set; }
    public int cnae { get; set; }
    public string? dataSituacaoCadastral { get; set; }
    public bool rejeitar { get; set; }
    public string? situacaoCadastral { get; set; }
    public string? nomeFantasia { get; set; }
    public int idadeEmpresa { get; set; }
    public int quantidadeFuncionarios { get; set; }
    public string? porteEmpresa { get; set; }
    public string? cnaeDescricao { get; set; }
    public string? cnaeGrupo { get; set; }
    public string? cnaeSubgrupo { get; set; }
    public string? naturezaJuridica { get; set; }
    public string? site { get; set; }
}

public class CnaeSecundario
{
    public string? descricao { get; set; }
    public string? grupo { get; set; }
    public string? cnae { get; set; }
}

public class Telefones
{
    public List<Telefone> fixos { get; set; }
    public List<Telefone> moveis { get; set; }
}

public class Telefone
{
    public string? numero { get; set; }
    public string? relacao { get; set; }
    public bool naoPerturbe { get; set; }
    public string? ultimoContato { get; set; }
    public Aplicativos aplicativos { get; set; }
}

public class Aplicativos
{
    public bool whatsApp { get; set; }
    public bool whatsAppBusiness { get; set; }
}

public class Endereco
{
    public string? tipoLogradouro { get; set; }
    public string? logradouro { get; set; }
    public int numero { get; set; }
    public string? complemento { get; set; }
    public string? bairro { get; set; }
    public string? cidade { get; set; }
    public string? uf { get; set; }
    public string? cep { get; set; }
    public string? latitude { get; set; }
    public string? longitude { get; set; }
}

public class Email
{
    public string? email { get; set; }
}

public class Socio
{
    public string? documento { get; set; }
    public string? nomeOuRazaoSocial { get; set; }
    public string? dataEntrada { get; set; }
}

public class HistoricoConsultasPorSegmento
{
    public List<string?> segmentos { get; set; }
    public int quantidadeTotal { get; set; }
}
