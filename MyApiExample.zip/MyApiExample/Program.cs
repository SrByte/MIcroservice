var builder = WebApplication.CreateBuilder(args);

// Adiciona os servi�os necess�rios para o controlador
builder.Services.AddControllers();

// Adiciona o Swagger para documenta��o da API
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configura o middleware Swagger para exibir a documenta��o
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API v1");
    });
}

app.UseHttpsRedirection();
app.MapControllers();

app.Run();
