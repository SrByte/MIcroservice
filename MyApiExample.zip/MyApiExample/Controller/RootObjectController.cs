﻿using Microsoft.AspNetCore.Mvc;
using MyApiExample.Models;
using Newtonsoft.Json;

namespace MyApiExample.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RootObjectController : ControllerBase
    {
        // POST api/rootobject
        [HttpPost]
        public IActionResult Post([FromBody] BigdataCorp rootObject)
        {
            if (rootObject == null)
            {
                return BadRequest("JSON inválido.");
            }

            try
            {
                // Serializa o objeto de volta para o JSON (opcional, se quiser enviar como resposta)
                var resultJson = JsonConvert.SerializeObject(rootObject, Formatting.Indented);

                // Retorna o JSON de volta
                return Ok(resultJson);
            }
            catch (Exception ex)
            {
                return BadRequest($"Erro ao processar o JSON: {ex.Message}");
            }
        }
    }
}
