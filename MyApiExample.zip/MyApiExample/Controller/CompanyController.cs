﻿namespace MyApiExample.Controller;
using Microsoft.AspNetCore.Mvc;
using MyApiExample.Adapter;
using MyApiExample.Models.Assertiva;

[ApiController]
[Route("api/[controller]")]
public class CompanyController : ControllerBase
{
    [HttpPost("convert")]
    public IActionResult ConvertToGenericModel([FromBody] Response jsonData, [FromQuery] int providerNumber)
    {
        try
        {
            // Usando o factory para obter o adaptador correto
            var adapter = GenericModelAdapterFactory.GetAdapter(providerNumber);

            // Convertendo o JSON usando o adaptador
            var genericModel = adapter.ConvertToGenericModel(jsonData);

            // Retorna o modelo genérico como JSON
            return Ok(genericModel);
        }
        catch (Exception ex)
        {
            // Tratar erros, como tipos de fontes inválidas
            return BadRequest(new { message = ex.Message });
        }
    }
}
