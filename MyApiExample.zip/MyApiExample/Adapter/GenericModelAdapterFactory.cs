﻿namespace MyApiExample.Adapter;
public class GenericModelAdapterFactory
{
    public static IGenericModelAdapter GetAdapter(int providerNumber)
    {
        //if (source == "Assertiva")
        //{
        return new AssertivaAdapter();
        //}
        //else if (source == "OutroTipo")
        //{
        //    return ; // Retorna o novo adaptador
        //}

        throw new ArgumentException("Fonte de dados não suportada", nameof(providerNumber));
    }
}
