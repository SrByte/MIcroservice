﻿namespace MyApiExample.Adapter;

using MyApiExample.Models.Assertiva;
using Newtonsoft.Json;

public class AssertivaAdapter : IGenericModelAdapter
{
    public GenericModel ConvertToGenericModel(Response jsonData)
    {
        // Desserializar o JSON da assertiva para a estrutura Assertiva
        //var assertivaData = JsonConvert.DeserializeObject<Response>(jsonData);

        //Criar uma nova instância do GenericModel e mapear os campos
        var genericModel = new GenericModel();

        genericModel.BasicData.TaxIdNumber = jsonData.resposta.dadosCadastrais.cnpj
                                                                        .Replace("/", "")
                                                                        .Replace(".", "")
                                                                        .Replace("-", "");
        genericModel.BasicData.OfficialName = jsonData.resposta.dadosCadastrais.razaoSocial;
        genericModel.BasicData.FoundedDate = jsonData.resposta.dadosCadastrais.dataAbertura;
        //genericModel.BasicData.FoundedDate = jsonData.resposta.dadosCadastrais.dataAbertura;
        //genericModel.BasicData.FoundedDate = jsonData.resposta.dadosCadastrais.dataAbertura;

        //Status = assertivaData.Resposta.DadosCadastrais.SituacaoCadastral,
        //Age = assertivaData.Resposta.DadosCadastrais.IdadeEmpresa,
        //HeadquartersState = assertivaData.Resposta.DadosCadastrais.Uf,
        //LegalNature = assertivaData.Resposta.DadosCadastrais.NaturezaJuridica,
        // Mapear outras propriedades conforme necessário
        //};

        //// Mapear atividades (CNAEs)
        //genericModel.Activities = assertivaData.Resposta.CnaesSecundarias.ConvertAll(cnae => new Activity
        //{
        //    IsMain = cnae.Cnae == assertivaData.Resposta.DadosCadastrais.Cnae.ToString(),
        //    Code = cnae.Cnae,
        //    Description = cnae.Descricao
        //});

        //// Mapear dados adicionais como Telefones e Endereços
        //genericModel.PhoneNumbers = assertivaData.Resposta.Telefones.Moveis
        //    .ConvertAll(t => new PhoneNumber
        //    {
        //        Number = t.Numero,
        //        Type = "Mobile",
        //        DoNotDisturb = t.NaoPerturbe
        //    });

        //genericModel.Addresses = assertivaData.Resposta.Enderecos.ConvertAll(e => new Address
        //{
        //    StreetType = e.TipoLogradouro,
        //    Street = e.Logradouro,
        //    Number = e.Numero,
        //    Complement = e.Complemento,
        //    Neighborhood = e.Bairro,
        //    City = e.Cidade,
        //    State = e.Uf,
        //    ZipCode = e.Cep
        //});

        //return genericModel;

        return genericModel;
    }
}

