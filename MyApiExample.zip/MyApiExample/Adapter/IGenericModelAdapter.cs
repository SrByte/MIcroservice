﻿using MyApiExample.Models.Assertiva;

namespace MyApiExample.Adapter;

public interface IGenericModelAdapter
{
    GenericModel ConvertToGenericModel(Response jsonData);
}
