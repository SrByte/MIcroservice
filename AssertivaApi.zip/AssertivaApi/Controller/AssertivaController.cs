﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text;

namespace AssertivaApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AssertivaController : ControllerBase
    {
        private readonly HttpClient _httpClient;

        public AssertivaController(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient();
        }

        [HttpPost("token")]
        public async Task<IActionResult> GetToken()
        {
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.assertivasolucoes.com.br/oauth2/v3/token");

            // Autenticação básica com usuário e senha
            var byteArray = Encoding.ASCII.GetBytes("lFi8GLdJE14NawhJrInjegcVwBYZM/bcuxSH0zuBeB+sb0xaUQ7mXd4Nk121zhMr6xHg4JXVymSbpYLC/FQwsA==:l7grzlaaSngR+ysTySmh65jqjJGZXNyQ2sNlKFelIACDu/ATeUE76lOp6LdMq435ElM9V+weYzatNMTD26f25g==");
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

            // Corpo da requisição
            var content = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("grant_type", "client_credentials")
            });
            request.Content = content;

            var response = await _httpClient.SendAsync(request);

            if (!response.IsSuccessStatusCode)
                return BadRequest("Falha ao obter o token");

            var responseData = await response.Content.ReadFromJsonAsync<JsonDocument>();
            var token = responseData?.RootElement.GetProperty("access_token").GetString();

            return Ok(new { Token = token });
        }

        [HttpGet("consulta")]
        public async Task<IActionResult> GetCnpjInfo([FromQuery] string cnpj, [FromHeader(Name = "Authorization")] string authorization)
        {
            var token = authorization?.Replace("Bearer ", "");

            var request = new HttpRequestMessage(HttpMethod.Get, $"https://api.assertivasolucoes.com.br/localize/v3/cnpj?cnpj={cnpj}&idFinalidade=1");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.SendAsync(request);

            if (!response.IsSuccessStatusCode)
                return BadRequest("Falha ao obter informações do CNPJ");

            var cnpjInfo = await response.Content.ReadAsStringAsync();
            return Ok(cnpjInfo);
        }

        [HttpPost("consulta-completa")]
        public async Task<IActionResult> PostAndGetCnpjInfo([FromQuery] string cnpj)
        {
            // Primeiro, obter o token
            var tokenResponse = await GetToken();
            if (tokenResponse is ObjectResult { Value: { } tokenData })
            {
                var token = ((dynamic)tokenData).Token;

                // Em seguida, usar o token para buscar as informações do CNPJ
                var request = new HttpRequestMessage(HttpMethod.Get, $"https://api.assertivasolucoes.com.br/localize/v3/cnpj?cnpj={cnpj}&idFinalidade=1");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                    return BadRequest("Falha ao obter informações do CNPJ");

                var cnpjInfo = await response.Content.ReadAsStringAsync();
                return Ok(cnpjInfo);
            }

            return BadRequest("Token inválido");
        }
    }
}
