var builder = WebApplication.CreateBuilder(args);

// Adiciona servi�os ao container (inje��o de depend�ncia)
builder.Services.AddControllersWithViews(); // Configura suporte para controladores com Views (MVC)

var app = builder.Build();

// Configura��o do pipeline de requisi��o HTTP
if (!app.Environment.IsDevelopment())
{
    // Configura��o para erros em produ��o
    app.UseExceptionHandler("/Home/Error"); // Redireciona para uma p�gina de erro padr�o
    app.UseHsts(); // For�a o uso de HTTPS em navegadores
}

// Redireciona automaticamente para HTTPS
app.UseHttpsRedirection();

// Configura o uso de arquivos est�ticos (CSS, JS, imagens, etc.)
app.UseStaticFiles();

// Configura o roteamento
app.UseRouting();

// Configura autoriza��o (para autentica��o ou permiss�es, se aplic�vel)
app.UseAuthorization();

// Configura a rota padr�o para o MVC
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Inicia o aplicativo
app.Run();
