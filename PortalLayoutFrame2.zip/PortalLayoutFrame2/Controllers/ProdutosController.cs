﻿using Microsoft.AspNetCore.Mvc;

public class ProdutosController : Controller
{
    private static List<Produto> _produtos = new List<Produto>
        {
            new Produto { Nome = "Produto 1", Preco = 10.00m, Quantidade = 100 },
            new Produto { Nome = "Produto 2", Preco = 20.00m, Quantidade = 200 }
        };

    public IActionResult Index()
    {
        ViewData["Title"] = "Gestão de Produtos";
        return View();
    }

    [HttpGet]
    public IActionResult GetProdutos()
    {
        return Json(_produtos);
    }

    [HttpPost]
    public IActionResult Create([FromBody] Produto novoProduto)
    {
        if (novoProduto == null || string.IsNullOrWhiteSpace(novoProduto.Nome))
        {
            return Json(new { success = false, message = "Dados inválidos para o novo produto." });
        }

        var produtoExistente = _produtos.FirstOrDefault(p => p.Nome == novoProduto.Nome);
        if (produtoExistente != null)
        {
            return Json(new { success = false, message = "Já existe um produto com este nome." });
        }

        _produtos.Add(novoProduto);
        return Json(new { success = true, message = "Produto criado com sucesso." });
    }


    [HttpPost]
    public IActionResult EditarProduto([FromBody] Produto produto)
    {
        var produtoExistente = _produtos.FirstOrDefault(p => p.Nome == produto.Nome);
        if (produtoExistente != null)
        {
            produtoExistente.Preco = produto.Preco;
            produtoExistente.Quantidade = produto.Quantidade;
            return Json(new { success = true, message = "Produto atualizado com sucesso." });
        }
        return Json(new { success = false, message = "Produto não encontrado." });
    }

    [HttpPost]
    public IActionResult ExcluirProduto([FromBody] string nome)
    {
        var produto = _produtos.FirstOrDefault(p => p.Nome == nome);
        if (produto != null)
        {
            _produtos.Remove(produto);
            return Ok("Produto excluído com sucesso.");
        }
        return NotFound("Produto não encontrado.");
    }
}

public class Produto
{
    public string Nome { get; set; }
    public decimal Preco { get; set; }
    public int Quantidade { get; set; }
}

