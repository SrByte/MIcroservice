using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace PortalLayout.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var salesData = GenerateSalesData();

            // Passa os dados como JSON
            ViewBag.SalesDataJson = JsonConvert.SerializeObject(salesData);
            return View();
        }

        private List<SalesData> GenerateSalesData()
        {
            var salesData = new List<SalesData>();
            var random = new Random();

            // Inicializar dados fict�cios para cada m�s de 2019 a 2021
            for (int year = 2019; year <= 2021; year++)
            {
                for (int month = 1; month <= 12; month++)
                {
                    var date = new DateTime(year, month, 1);
                    salesData.Add(new SalesData
                    {
                        Month = date.ToString("MMM yyyy"), // Nome do m�s e ano, ex: Jan 2019
                        ChocolateSales = random.Next(50, 500),  // Valores aleat�rios de vendas de chocolate
                        CoffeeSales = random.Next(30, 400),     // Valores aleat�rios de vendas de caf�
                        PanettoneSales = random.Next(20, 300),  // Valores aleat�rios de vendas de panetone
                        Consumers = random.Next(100, 1000)      // Valores aleat�rios de consumidores
                    });
                }
            }

            return salesData;
        }
    }

    // Modelo SalesData
    public class SalesData
    {
        public string Month { get; set; }
        public int ChocolateSales { get; set; }
        public int CoffeeSales { get; set; }
        public int PanettoneSales { get; set; }
        public int Consumers { get; set; }
    }
}
