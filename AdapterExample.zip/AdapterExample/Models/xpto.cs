﻿// Xpto/Models/Xpto.cs
namespace AdapterExample.Models
{
    public class Xpto
    {
        public List<Result> Results { get; set; }
    }

    public class Result
    {
        public string MatchKeys { get; set; }
        public BasicData BasicData { get; set; }
        public List<Activity> Activities { get; set; }
        public LegalNature LegalNature { get; set; }
        public ContactInformation ContactInformation { get; set; }
        public List<Address> Addresses { get; set; }
        public List<Partner> Partners { get; set; }
    }

    public class BasicData
    {
        public string TaxIdNumber { get; set; }
        public string TaxIdCountry { get; set; }
        public Dictionary<string, string> AlternativeIdNumbers { get; set; }
        public string OfficialName { get; set; }
        public string TradeName { get; set; }
        public Dictionary<string, string> Aliases { get; set; }
        public int NameUniquenessScore { get; set; }
        public int OfficialNameUniquenessScore { get; set; }
        public int TradeNameUniquenessScore { get; set; }
        public DateTime FoundedDate { get; set; }
        public int Age { get; set; }
        public bool IsHeadquarter { get; set; }
        public string HeadquarterState { get; set; }
        public bool IsConglomerate { get; set; }
        public string TaxIdStatus { get; set; }
        public string TaxIdOrigin { get; set; }
        public DateTime TaxIdStatusDate { get; set; }
        public DateTime TaxIdStatusRegistrationDate { get; set; }
        public string TaxRegime { get; set; }
        public string CompanyTypeReceitaFederal { get; set; }
        public string PorteEmpresa { get; set; }
        public int QuantidadeFuncionarios { get; set; }
        public TaxRegimes TaxRegimes { get; set; }
    }

    public class TaxRegimes
    {
        public bool Simples { get; set; }
    }

    public class Activity
    {
        public bool IsMain { get; set; }
        public string Code { get; set; }
        public string ActivityName { get; set; }
        public string Group { get; set; }
        public string Subgroup { get; set; }
        public string Description { get; set; }
    }

    public class LegalNature
    {
        public string Code { get; set; }
        public string Activity { get; set; }
    }

    public class ContactInformation
    {
        public List<Phone> Phones { get; set; }
        public List<Email> Emails { get; set; }
    }

    public class Phone
    {
        public string Number { get; set; }
        public string Relation { get; set; }
        public bool DoNotDisturb { get; set; }
        public string LastContact { get; set; }
        public Applications Applications { get; set; }
    }

    public class Applications
    {
        public bool WhatsAppBusiness { get; set; }
        public bool WhatsApp { get; set; }
    }

    public class Email
    {
        public string EmailAddress { get; set; }
    }

    public class Address
    {
        public string Type { get; set; }
        public string Street { get; set; }
        public int Number { get; set; }
        public string Complement { get; set; }
        public string Neighborhood { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }

    public class Partner
    {
        public string Document { get; set; }
        public string Name { get; set; }
        public DateTime EntryDate { get; set; }
    }
}
