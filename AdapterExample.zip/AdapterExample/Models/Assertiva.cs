﻿// Assertivo/Models/Assertivo.cs
namespace AdapterExample.Models
{
    public class Assertivo
    {
        public Resposta Resposta { get; set; }
        public string Alerta { get; set; }
    }

    public class Resposta
    {
        public DadosCadastrais DadosCadastrais { get; set; }
        public List<CnaeSecundario> CnaesSecundarios { get; set; }
        public TelefoneInfo Telefones { get; set; }
        public List<Endereco> Enderecos { get; set; }
        public List<Socio> Socios { get; set; }
    }

    public class DadosCadastrais
    {
        public string Cnpj { get; set; }
        public string RazaoSocial { get; set; }
        public DateTime DataAbertura { get; set; }
        public int Cnae { get; set; }
        public DateTime DataSituacaoCadastral { get; set; }
        public bool Rejeitar { get; set; }
        public string SituacaoCadastral { get; set; }
        public string? NomeFantasia { get; set; }
        public int IdadeEmpresa { get; set; }
        public int QuantidadeFuncionarios { get; set; }
        public string PorteEmpresa { get; set; }
        public string CnaeDescricao { get; set; }
        public string CnaeGrupo { get; set; }
        public string CnaeSubgrupo { get; set; }
        public string NaturezaJuridica { get; set; }
        public string? Site { get; set; }
        public string? Uf { get; set; }

    }

    public class CnaeSecundario
    {
        public string Descricao { get; set; }
        public string Grupo { get; set; }
        public string Cnae { get; set; }
    }

    public class TelefoneInfo
    {
        public List<Telefone> Fixos { get; set; }
        public List<Telefone> Moveis { get; set; }
    }

    public class Telefone
    {
        public string Numero { get; set; }
        public string Relacao { get; set; }
        public bool NaoPerturbe { get; set; }
        public string UltimoContato { get; set; }
        public Aplicativos Aplicativos { get; set; }
    }

    public class Aplicativos
    {
        public bool WhatsApp { get; set; }
        public bool WhatsAppBusiness { get; set; }
    }

    public class Endereco
    {
        public string TipoLogradouro { get; set; }
        public string Logradouro { get; set; }
        public int Numero { get; set; }
        public string Complemento { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string Uf { get; set; }
        public string Cep { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }

    public class Socio
    {
        public string Documento { get; set; }
        public string NomeOuRazaoSocial { get; set; }
        public DateTime DataEntrada { get; set; }
    }
}
