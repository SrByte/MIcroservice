﻿// Adapters/AssertivoToXptoAdapter.cs
using AdapterExample.Models;

namespace AdapterExample.Adapters
{
    public class AssertivoToXptoAdapter
    {
        public Xpto Adapt(Assertivo input)
        {
            var result = new Result
            {
                MatchKeys = $"doc{{{input.Resposta.DadosCadastrais.Cnpj}}}",
                BasicData = new BasicData
                {
                    TaxIdNumber = input.Resposta.DadosCadastrais.Cnpj.Replace(".", "").Replace("/", "").Replace("-", ""),
                    TaxIdCountry = "Brazil",
                    AlternativeIdNumbers = new Dictionary<string, string>
                    {
                        { "stateRegistrationSP", "149.969.920.110" }
                    },
                    OfficialName = input.Resposta.DadosCadastrais.RazaoSocial,
                    TradeName = input.Resposta.DadosCadastrais.NomeFantasia,
                    Aliases = new Dictionary<string, string>
                    {
                        { "unstandardizedRFOfficialName", input.Resposta.DadosCadastrais.RazaoSocial },
                        { "unstandardizedRFTradeName", input.Resposta.DadosCadastrais.NomeFantasia ?? "" }
                    },
                    FoundedDate = input.Resposta.DadosCadastrais.DataAbertura,
                    Age = input.Resposta.DadosCadastrais.IdadeEmpresa,
                    IsHeadquarter = true,
                    HeadquarterState = input.Resposta.DadosCadastrais.Uf,
                    TaxIdStatus = input.Resposta.DadosCadastrais.SituacaoCadastral,
                    TaxIdOrigin = "Receita Federal",
                    TaxIdStatusDate = input.Resposta.DadosCadastrais.DataSituacaoCadastral,
                    TaxRegime = input.Resposta.DadosCadastrais.NaturezaJuridica,
                    CompanyTypeReceitaFederal = "EPP",
                    PorteEmpresa = input.Resposta.DadosCadastrais.PorteEmpresa,
                    QuantidadeFuncionarios = input.Resposta.DadosCadastrais.QuantidadeFuncionarios
                },
                Activities = input.Resposta.CnaesSecundarios.Select(c => new Activity
                {
                    Code = c.Cnae,
                    ActivityName = c.Descricao,
                    Group = c.Grupo
                }).ToList(),
                LegalNature = new LegalNature
                {
                    Code = "2062", // Exemplo
                    Activity = input.Resposta.DadosCadastrais.NaturezaJuridica
                },
                ContactInformation = new ContactInformation
                {
                    //Phones = input.Resposta.Telefones.Fixos.Concat(input.Resposta.Telefones.Moveis).ToList(),
                    Phones = new(),
                    Emails = input.Resposta.Enderecos.Select(e => new Email { EmailAddress = e.Cidade }).ToList()
                },
                Addresses = input.Resposta.Enderecos.Select(e => new Address
                {
                    Type = e.TipoLogradouro,
                    Street = e.Logradouro,
                    Number = e.Numero,
                    Complement = e.Complemento,
                    Neighborhood = e.Bairro,
                    City = e.Cidade,
                    State = e.Uf,
                    PostalCode = e.Cep
                }).ToList(),
                Partners = input.Resposta.Socios.Select(s => new Partner
                {
                    Document = s.Documento,
                    Name = s.NomeOuRazaoSocial,
                    EntryDate = s.DataEntrada
                }).ToList()
            };

            return new Xpto { Results = new List<Result> { result } };
        }
    }
}
