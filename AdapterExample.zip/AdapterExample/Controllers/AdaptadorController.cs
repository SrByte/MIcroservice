﻿    // Controllers/AdaptadorController.cs
using AdapterExample.Models;
using AdapterExample.Adapters;
using Microsoft.AspNetCore.Mvc;

namespace AdapterExample.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdaptadorController : ControllerBase
    {
        private readonly AssertivoToXptoAdapter _adapter;

        public AdaptadorController()
        {
            _adapter = new AssertivoToXptoAdapter();
        }

        [HttpPost("adaptar")]
        public ActionResult<Xpto> Adaptar([FromBody] Assertivo assertivo)
        {
            if (assertivo == null)
                return BadRequest("Dados inválidos.");

            var xpto = _adapter.Adapt(assertivo);
            return Ok(xpto);
        }
    }
}
