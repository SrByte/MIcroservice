﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LegumesAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FrutasController : ControllerBase
    {
        [HttpGet]
        [Authorize(AuthenticationSchemes = "FrutasScheme")]
        public IActionResult GetFrutas()
        {
            if (Request.Headers.TryGetValue("X-Custom-Header", out var cabecalhoValor))
            {
                // Utiliza o valor do cabeçalho
                var x =  cabecalhoValor ;
            }

            var legumes = new List<string>
            {
                "Banana",
                "Abacate",
                "Maça",
                "Uva",
                "Goiaba",
                "Manga",
                "Acerola",
                "Fruta do Conde",
                "Limão",
                "Laranja"
            };

            return Ok(legumes);
        }
    }
}
