﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LegumesAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LegumesController : ControllerBase
    {
        [HttpGet]
        [Authorize(AuthenticationSchemes = "LegumesScheme")]
        public IActionResult GetLegumes()
        {
            if (Request.Headers.TryGetValue("X-Custom-Header", out var cabecalhoValor))
            {
                // Utiliza o valor do cabeçalho
                var x =  cabecalhoValor ;
            }

            var legumes = new List<string>
            {
                "Cenoura",
                "Batata",
                "Tomate",
                "Pepino",
                "Abobrinha",
                "Berinjela",
                "Pimentão",
                "Couve-flor",
                "Brócolis",
                "Espinafre"
            };

            return Ok(legumes);
        }
    }
}
